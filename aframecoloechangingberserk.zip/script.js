$ = (queryString) => document.querySelector(queryString);

const shiftHue = (hue) => (hue + 1) % 1000;

let hue = 0;

const tint = () => {
  hue = shiftHue(hue);
  const color = `hsl(${hue}, 100%, 40%)`;
  $('a-sky').setAttribute('color', color);
  requestAnimationFrame(tint);
};

requestAnimationFrame(tint);